import React from 'react';
import Navbar from "../../Navbar/Navbar";
import styles from "../../Tarjeta/Card.module.scss";
import Footer from "../../Footer/Footer";
export const Home = () => {
  return (
    <main>
      <Navbar></Navbar>
      <div className={styles.Card}>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>        
        <br></br>
        <br></br>
        <br></br>
        <br></br>        
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
      </div>
      <Footer />
    </main>
  )
}
